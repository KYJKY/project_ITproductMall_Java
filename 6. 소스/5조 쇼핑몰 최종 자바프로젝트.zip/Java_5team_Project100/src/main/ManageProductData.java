package main;

public class ManageProductData {
	public static boolean main() {
		// 관리자 - 상품 관리
		return true;
	}
}
