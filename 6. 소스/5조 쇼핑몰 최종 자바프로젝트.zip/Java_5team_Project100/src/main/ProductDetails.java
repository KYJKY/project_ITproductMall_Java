package main;

public class ProductDetails {
	public static boolean main() {
		
		return true;
	}
}
