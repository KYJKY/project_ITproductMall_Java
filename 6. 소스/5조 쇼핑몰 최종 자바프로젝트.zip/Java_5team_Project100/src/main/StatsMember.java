package main;

import createObject.Member;

public class StatsMember {
	public static boolean main() {
	
		return true;
	}

	
}
